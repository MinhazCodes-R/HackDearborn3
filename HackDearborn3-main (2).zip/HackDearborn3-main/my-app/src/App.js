import logo from './logo.svg';
import './App.css';
import React from 'react';
import TripForm from './components/TripForm'; 

function App() {
  return (
    <div>
        <TripForm />
    </div>
  );
}

export default App;
